<?php

$users = [
    "erik@tec.mx" => [
        "name" => "Erik",
        "lastname" => "Sánchez",
        "password" => "erik123"
    ]
];

$username = $_POST["username"];
$pass = $_POST["pass"];

if( isset($users[$username]) && ($users[$username]["password"] === $pass) ){
    //Login válido
    session_start();

    $user = $users[$username];
    $_SESSION["username"] = $username;
    $_SESSION["name"] = $user["name"];
    $_SESSION["started_at"] = time();
    $_SESSION["started"] = true;

    //Redirigir
    header("Location: ./products.php");

}
else{
    //Login inválido
    header("Location: ./productsList.php");
}
