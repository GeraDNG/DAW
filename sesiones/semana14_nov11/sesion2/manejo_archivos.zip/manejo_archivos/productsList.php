<?php

require_once "./json_example/json.php";

function getProducts(){

    $data = [];
    $file = fopen("./products.csv", "r");

    if($file){

        while($line = fgetcsv($file)){
            $data[] = $line;
        }

        return $data;

    }
    else{
        return false;
    }

}

function getProductsJson(){
    $file = "./json_example/products.json";
    return loadJson($file);
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>

        <a href="./products.php">New Product</a>
        <br/><br/>

        <table border="1">
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Qty</th>
            </tr>
            <?php foreach (getProductsJson() as $product){ ?>

                <tr>
                    <td><?php echo $product["name"] ?></td>
                    <td><?php echo $product["price"] ?></td>
                    <td><?php echo $product["qty"] ?></td>
                </tr>

            <?php } ?>

        </table>

    </body>
</html>
