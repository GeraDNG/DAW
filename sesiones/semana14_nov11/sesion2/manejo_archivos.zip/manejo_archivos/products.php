<?php
session_start();

if(!isset($_SESSION["started"]) || !$_SESSION["started"]){
    header("Location: ./login.php");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>

        <h1>Bienvenido <?php echo $_SESSION["name"]; ?></h1>

        <a href="./productsList.php">Products List</a>
        <br/><br/>

        <form class="" action="./json_example/saveProduct.php" method="post">

            <!-- <label for=""><strong>ID: </strong></label>
            <input type="text" name="id" value="" /><br/><br/> -->

            <label for=""><strong>Name: </strong></label>
            <input type="text" name="name" value="" /><br/><br/>

            <label for=""><strong>Price: </strong></label>
            <input type="number" name="price" value="" /><br/><br/>

            <label for=""><strong>QTY: </strong></label>
            <input type="number" name="qty" value="" /><br/><br/>

            <input type="submit" name="saveProduct" value="Save" />

        </form>

    </body>
</html>
