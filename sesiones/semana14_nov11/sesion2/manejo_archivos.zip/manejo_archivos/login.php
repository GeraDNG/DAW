<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>

        <form action="./login_control.php" method="post">

            <label for="username"><strong>User: </strong></label>
            <input type="text" name="username" value="" />
            <br/><br/>
            <label for="pass"><strong>Password: </strong></label>
            <input type="password" name="pass" value="" />
            <br/><br/>

            <input type="submit" name="login" value="Sign In" />

        </form>

    </body>
</html>
