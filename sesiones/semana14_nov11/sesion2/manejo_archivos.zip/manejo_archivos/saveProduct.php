<?php

$data = [uniqid(),$_POST["name"],$_POST["price"],$_POST["qty"]];
$data = implode(",",$data) . "\n";

if(@file_put_contents("./products.csv", $data, FILE_APPEND)){
    header("Location: ./productsList.php");
}
else{
    echo "Ha ocurrido un error al escribir en el archivo";
}
