<?php

/*
Este archivo se encarga de leer un JSON del sistema de archivos y devolverlo
como una estructura de datos
*/

//Devuelve una estructura de datos con la información del JSON
function loadJson($path){

    if($data = @file_get_contents($path)){
        return json_decode($data, true);
    }

    return false;

}

//Escribe el contenido de una estructura de datos en un archivo JSON
function writeJson($path,$data){

    if(!empty($data)){
        return @file_put_contents($path, json_encode($data));
    }

    return false;

}
