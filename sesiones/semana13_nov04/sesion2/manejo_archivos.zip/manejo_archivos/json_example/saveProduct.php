<?php

require_once "./json.php";

$file = "./products.json";

$product = [
            "name" => $_POST["name"],
            "price" => $_POST["price"],
            "qty" => $_POST["qty"]
        ];

if($productsList = loadJson($file)){

    $productsList[uniqid()] = $product;

    if(writeJson($file, $productsList)){
        header("Location: ../productsList.php");
    }
    else{
        echo "Ha ocurrido un error al escribir en el archivo";
    }

}




/*
$data = [uniqid(),$_POST["name"],$_POST["price"],$_POST["qty"]];
$data = implode(",",$data) . "\n";

if(@file_put_contents("./products.csv", $data, FILE_APPEND)){
    header("Location: ./productsList.php");
}
else{
    echo "Ha ocurrido un error al escribir en el archivo";
}
*/
