<?php

echo "Carrera: " . $_GET["carrera"];
