/********************************
            VARIABLES
*********************************/

var board = [];
var openCards = 0;

/********************************
            FUNCTIONS
*********************************/

//Valida que pueda generarse el memorama
function validateConfig(memorama){

    var numCards = memorama.size.rows * memorama.size.cols;

    if( (numCards % 2) !== 0 ){
        alert("El número de cartas debe ser par");
        return false;
    }
    //Si el rango es suficiente para generar los números
    if( (numCards/2) > (memorama.numRange.max - memorama.numRange.min) ){
        alert("Rango insuficente");
        return false;
    }

    return true;

}

//Genera el listado de números para el memorama
function generateNumbers(memorama){

    var numCards = (memorama.size.rows * memorama.size.cols)/2;
    var numbers = [];
    var usedNumbers = {};

    while(numbers.length < numCards){

        var num = randomNumber(memorama.numRange.min, memorama.numRange.max);

        if(typeof usedNumbers[num] === "undefined"){
            numbers.push(num);
            usedNumbers[num] = true;
        }

    }

    return numbers.concat(numbers);

}

//Función que llena el tablero virtual
function fillBoard(numbers, size){

    var counter = 0;

    for(var i = 0; i < size.rows; i++){

        if(typeof board[i] === "undefined"){
            board[i] = [];
        }

        for(var j = 0; j < size.cols; j++){
            board[i][j] = numbers[counter];
            counter++;
        }

    }

}

//Mezcla las tarjetas del tablero virtual
function mixBoard(){

    var rows = board.length;
    var cols = board[0].length;

    for(var i = 0; i < rows; i++){

        for(var j = 0; j < cols; j++){
            //Generar nueva posición
            var newRow = randomNumber(0, (rows - 1));
            var newCol = randomNumber(0, (cols - 1));
            //Guardar elemento en variable temporal
            var temp = board[i][j];
            //Asignar elementos
            board[i][j] = board[newRow][newCol];
            board[newRow][newCol] = temp;

        }

    }

}

//Construye una carta
function buildCard(number){

    /*
    <div class="card">
        <span class="card-value">10</span>
    </div>
    */

    //crear contenedor
    var card = document.createElement("div");
    card.className = "card";
    card.dataset.value = number;

    //Crear span
    var span = document.createElement("span");
    span.className = "card-value";
    span.innerHTML = number;

    //Agregar el span al div
    card.appendChild(span);

    //Agregar listener de click
    card.addEventListener("click", function(event){

        if(openCards < 2){

            var clickedCard = event.target;
            var cardNumber = clickedCard.dataset.value;
            clickedCard.className = "card open";

            //Mostrar el número
            clickedCard.querySelector("span").style.visibility = "visible";

            //Incrementar el contador
            openCards++;

        }

        if(openCards == 2){
            //Esconder el número después de X tiempo
            setTimeout(function(){

                var opened = document.querySelectorAll(".card.open");

                console.log("opened", opened);

                for(var i = 0; i < opened.length; i++){
                    var cardValue = opened[i].querySelector(".card-value");
                    cardValue.style.visibility = "hidden";
                    opened[i].className = "card";
                }

                openCards = 0;

            },2000);
        }

    });

    return card;

}

//Genera el tablero en el DOM
function buildBoard(memorama){

    //Validar que se pueda generar
    if( validateConfig(memorama) ){

        //Generar los números aleatorios duplicados
        var numbers = generateNumbers(memorama);
        //Llenar el tablero virtual con los números
        fillBoard(numbers, memorama.size);
        //Mezclar el tablero
        mixBoard();

        console.log("debug-board", board);

        var container = document.querySelector("#board");

        //Generar las cartas
        for(var i = 0; i < board.length; i++){

            for(var j = 0; j < board[0].length; j++){
                //Construye una carta
                var card = buildCard(board[i][j]);
                //Agregarlo al contenedor
                container.appendChild(card);
            }

            container.appendChild(document.createElement("br"));

        }

    }

    /*
    var itemsList = document.querySelector("#items-list");

    for(var index in items){

        items[index].id = index;
        //Generar el elemento
        var item = buildItem(items[index]);
        //Agregar a la lista
        itemsList.appendChild(item);

    }
    */

}


/********************************
        EVENT LISTENERS
*********************************/

document.addEventListener("DOMContentLoaded", function(event){

    //Obtener el ID del memorama
    var id = getParameter("id");

    //Generar los parámetros
    var params = new URLSearchParams({"id": id});

    //Cargar el JSON con la configuración del memorama
    fetch('./php/api.php', {
        method: "POST",
        body: params
    })
    .then(function(response){

        response.json().then(function(data){
            //Construir el tablero
            console.log("debug-data", data);
            buildBoard(data);
        });

    });

});

/********************************
            LOGIC
*********************************/
