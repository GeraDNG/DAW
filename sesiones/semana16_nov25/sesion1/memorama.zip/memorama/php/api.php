<?php

/********************************
            INCLUDES
*********************************/

require_once "./json.php";

/********************************
            VARIABLES
*********************************/

define("JSON_PATH", "../json/config.json");

/********************************
            FUNCTIONS
*********************************/

function getLevels(){

    if($data = loadJson(JSON_PATH)){

        uasort($data, function($a, $b){
            return $a["level"] - $b["level"];
        });

    }

    return $data;

}

function getMemorama($id){

    if($data = loadJson(JSON_PATH)){
        return $data[$id];
    }

}

/********************************
            LOGIC
*********************************/

$method = strtolower($_SERVER["REQUEST_METHOD"]);

switch($method){
    case "get":
        die(json_encode(getLevels()));
    case "post":
        die(json_encode(getMemorama($_POST["id"])));
}
