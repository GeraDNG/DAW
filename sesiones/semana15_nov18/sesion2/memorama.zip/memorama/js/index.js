/********************************
            VARIABLES
*********************************/

/********************************
            FUNCTIONS
*********************************/

//Construye un item de la lista
function buildItem(data){
    /*
    <div class="item">
        <a href="./memorama.html?id=1" target="_blank">Memorama 1</a>
    </div>
    */

    var item = document.createElement("div");
    //Agregar clases
    item.className = "item";

    //Crear el link
    var link = document.createElement("a");
    link.href = "./memorama.html?id=" + data.id;
    link.target = "_blank";
    link.innerHTML = data.title;

    //Insertar el link en el item
    item.appendChild(link);

    return item;

}

//Genera la lista de items y los agrega al DOM
function buildItemsList(items){

    var itemsList = document.querySelector("#items-list");

    for(var index in items){

        items[index].id = index;
        //Generar el elemento
        var item = buildItem(items[index]);
        //Agregar a la lista
        itemsList.appendChild(item);

    }

}


/********************************
        EVENT LISTENERS
*********************************/

document.addEventListener("DOMContentLoaded", function(event){

    var itemsContainer = document.querySelector("#items-list");

    //Cargar el JSON con los memoramas
    fetch('./php/api.php').then(function(response){

        response.json().then(function(data){
            //Construir la lista
            buildItemsList(data);
        });

    });

});

/********************************
            LOGIC
*********************************/
