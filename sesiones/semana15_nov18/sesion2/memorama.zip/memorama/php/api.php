<?php

/********************************
            INCLUDES
*********************************/

require_once "./json.php";

/********************************
            VARIABLES
*********************************/

define("JSON_PATH", "../json/config.json");

/********************************
            FUNCTIONS
*********************************/

function getLevels(){

    if($data = loadJson(JSON_PATH)){

        uasort($data, function($a, $b){
            return $a["level"] - $b["level"];
        });

    }

    return $data;

}

/********************************
            LOGIC
*********************************/

die(json_encode(getLevels()));
