<header class="bg-primary-0" id="main-header">
    <h1>CSS Layout Example</h1>
</header>

<nav class="bg-primary-1">
    <ul class="wrapper">
        <li><a href="./areas.php">Areas</a></li>
        <li><a href="./perimeters.php">Perimeters</a></li>
        <li><a href="#">Link 3</a></li>
        <li><a href="#">Link 4</a></li>
    </ul>
</nav>
