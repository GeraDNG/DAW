<?php

$name = isset($_GET["key"]) ? strtolower($_GET["key"]) : null;
$lastname = null;

if(empty($name)){
    die("El nombre no está definido");
}

switch($name){
    case "martin":
        $lastname = "Calderón";
        break;
    case "jenny":
        $lastname = "Rubio";
        break;
    case "dan":
        $lastname = "Gámez";
        break;
    default:
        $lastname = "Not found";
        break;
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <strong>El nombre es: </strong><?php echo "$name $lastname"; ?>
    </body>
</html>
