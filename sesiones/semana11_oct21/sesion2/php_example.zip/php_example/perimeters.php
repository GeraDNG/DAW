<?php
require "./functions.php";
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Basic Layout</title>

        <link rel="stylesheet" href="./css/main.css" />

    </head>

    <body>

        <?php require_once "./partials/header.php"; ?>

        <section class="wrapper" id="main-content">

            <header class="center">
                <h2>Contenido</h2>
            </header>

            <strong>El perímetro de un círculo de radio = 10 es:</strong>
            <?php echo circlePerimeter(10); ?>

        </section>

        <?php require_once "./partials/footer.php"; ?>

    </body>

</html>
