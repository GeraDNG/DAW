<?php

define("PI", 3.1416);

$radio = 100;

function circleArea($radio = 5){
    return PI * pow($radio, 2);
}

function circlePerimeter($radio = 5){
    return PI * $radio * 2;
}

var_dump($_SERVER);die();
