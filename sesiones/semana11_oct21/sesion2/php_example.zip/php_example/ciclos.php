<?php

$students = [
    ["name" => "Randy", "lastname" => "Jiménez"],
    ["name" => "Eduardo", "lastname" => "Hernández"],
    ["name" => "Gerardo", "lastname" => "Naranjo"],
    ["name" => "Marco", "lastname" => "García"]
];

//$students[3]["lastname"];

$studentsAssoc = [
    "A01251333" => ["name" => "Randy", "lastname" => "Jiménez"],
    "A01371447" => ["name" => "Eduardo", "lastname" => "Hernández"],
    "A01209499" => ["name" => "Gerardo", "lastname" => "Naranjo"],
    "A01700469" => ["name" => "Marco", "lastname" => "García"]
];

//$studentsAssoc["A01700469"]["lastname"];

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>

        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Lastname</th>
                </tr>
            </thead>

            <tbody>

            <?php
            //for($i = 0; $ < sizeof($students); $i++){
            foreach($studentsAssoc as $key => $student){
                echo "<tr>";
                echo "<td>$key</td>";
                echo "<td>" . $student["name"] . "</td>";
                echo "<td>" . $student["lastname"] . "</td>";
                echo "</tr>";
            }
            ?>

            </tbody>
        </table>

    </body>
</html>
