<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>

        <h1>PHP Example</h1>

        <?php

        define("PI", 3.1416);

        $name = "Randy";
        $var = "hola $name";
        $arr = ["esto","es","un","arreglo"];
        echo "<h2>$var</h2>";//<h2>hola</h2>
        echo '<h2>El valor de PI es:' . PI . '</h2>';//<h2>$var</h2>

        $num = $_GET["devMode"];

        if($num === "true"){
            echo "devMode activado " . $num;
        }
        else{
            echo "Dev mode desactivado";
        }

        echo "<br/>";

        var_dump($_GET);

        echo "<br/>";

        print_r($_GET);

        ?>

    </body>
</html>
